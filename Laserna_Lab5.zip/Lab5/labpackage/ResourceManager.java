//storing managing resources
package labpackage;

public class ResourceManager {
    //initialize resources
    public int water;
    public int milk;
    public int coffeeBeans;

    public ResourceManager(int water, int milk, int coffeeBeans) {
        this.water = water;
        this.milk = milk;
        this.coffeeBeans = coffeeBeans;
    }

    public int getWater(){
        return water;
    }

    public int getMilk(){
        return milk;
    }

    public int getCoffeeBeans(){
        return coffeeBeans;
    }

    //are there enough resources (i.e. cost)
    public boolean enoughResources(int waterNeeded, int milkNeeded, int coffeeBeansNeeded){
        return (water >= waterNeeded && milk >= milkNeeded && coffeeBeans >= coffeeBeansNeeded);
    }

    //deduction of resources
    public void deductResources(int waterNeeded, int milkNeeded, int coffeeBeansNeeded){
        water -= waterNeeded;
        milk -= milkNeeded;
        coffeeBeans -= coffeeBeansNeeded;
    }
}

//concrete class extension of coffee
package labpackage;

public class CoffeeLatte extends Coffee {
    public CoffeeLatte(){
        super(300,300,100,3.50);
    }

    @Override
    public String getCoffeeName(){
        return "Latte";
    }
}

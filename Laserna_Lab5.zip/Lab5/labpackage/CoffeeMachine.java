//main class including most methods
package labpackage;
import java.util.Scanner;

public class CoffeeMachine {
    private ResourceManager resourceManager;
    private double money;

    public CoffeeMachine(ResourceManager resourceManager, double money) {
        this.resourceManager = resourceManager;
        this.money = 0.0;
    }

    public static void main(String[] args) {
        ResourceManager initialResources = new ResourceManager(1000, 1000, 500);
        CoffeeMachine coffeeMachine = new CoffeeMachine(initialResources, 0);
        coffeeMachine.runMachine();
    }

    //runMachine method
    public void runMachine() {
        Scanner userInput = new Scanner(System.in);
        System.out.println("   _      _      _      _      _      _      _      _      _      _      _      _      _   \r\n" + //
                " _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_ \r\n" + //
                "(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)\r\n" + //
                " (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_) \r\n" + //
                "                                                                                           \r\n" + //
                "   _                                   WELCOME TO                                          \r\n" + //
                " _( )_     __     ______     ______     __  __     ______     __  __     ______      _( )_ \r\n" + //
                "(_ o _)   /\\ \\   /\\  __ \\   /\\  == \\   /\\ \\/\\ \\   /\\  ___\\   /\\ \\/ /    /\\  ___\\    (_ o _)\r\n" + //
                " (_,_)   _\\_\\ \\  \\ \\  __ \\  \\ \\  __<   \\ \\ \\_\\ \\  \\ \\ \\____  \\ \\  _\"-.  \\ \\___  \\    (_,_) \r\n" + //
                "   _    /\\_____\\  \\ \\_\\ \\_\\  \\ \\_____\\  \\ \\_____\\  \\ \\_____\\  \\ \\_\\ \\_\\  \\/\\_____\\     _   \r\n" + //
                " _( )_  \\/_____/   \\/_/\\/_/   \\/_____/   \\/_____/   \\/_____/   \\/_/\\/_/   \\/_____/   _( )_ \r\n" + //
                "(_ o _)                                                                             (_ o _)\r\n" + //
                " (_,_)                                                                               (_,_) \r\n" + //
                "   _      _      _      _      _      _      _      _      _      _      _      _      _   \r\n" + //
                " _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_  _( )_ \r\n" + //
                "(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)(_ o _)\r\n" + //
                " (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_)  (_,_) ");
        while (true){
            System.out.println("\nWhat would you like today mamser?\nEspresso - $2.50\nLatte - $3.50\nCappuccino - $5.50\nOff\nReport\n\nType Here: ");
            String choice = userInput.nextLine().toLowerCase();

            switch (choice) {
                case "off":
                    System.out.println("\r\n" + //
                            "░░░░░░░░░░░░░▄▄▄▄▄▄▄░░░░░░░░░\r\n" + //
                            "░░░░░░░░░▄▀▀▀░░░░░░░▀▄░░░░░░░\r\n" + //
                            "░░░░░░░▄▀░░░░░░░░░░░░▀▄░░░░░░\r\n" + //
                            "░░░░░░▄▀░░░░░░░░░░▄▀▀▄▀▄░░░░░\r\n" + //
                            "░░░░▄▀░░░░░░░░░░▄▀░░██▄▀▄░░░░\r\n" + //
                            "░░░▄▀░░▄▀▀▀▄░░░░█░░░▀▀░█▀▄░░░\r\n" + //
                            "░░░█░░█▄░░░░█░░░▀▄░░░░░▐░█░░░\r\n" + //
                            "░░▐▌░░█▀░░░▄▀░░░░░▀▄▄▄▄▀░░█░░\r\n" + //
                            "░░▐▌░░█░░░▄▀░░░░░░░░░░░░░░█░░\r\n" + //
                            "░░▐▌░░░▀▀▀░░░░░░░░░░░░░░░░▐▌░\r\n" + //
                            "░░▐▌░░░░░░░░░░░░░░░▄░░░░░░▐▌░\r\n" + //
                            "░░▐▌░░░░░░░░░▄░░░░░█░░░░░░▐▌░\r\n" + //
                            "░░░█░░░░░░░░░▀█▄░░▄█░░░░░░▐▌░\r\n" + //
                            "░░░▐▌░░░░░░░░░░▀▀▀▀░░░░░░░▐▌░\r\n" + //
                            "░░░░█░░░░░░░░░░░░░░░░░░░░░█░░\r\n" + //
                            "░░░░▐▌▀▄░░░░░░░░░░░░░░░░░▐▌░░\r\n" + //
                            "░░░░░█░░▀░░░░░░░░░░░░░░░░▀░░░\r\n" + //
                            "░░░░░       K BYE       ░░░░░\r\n" + //
                            "░░░░░█░░▀░░░░░░░░░░░░░░░░▀░░░\r\n" + //
                            "");
                    return;
                case "report":
                    printReport();
                    break;
                case "espresso": case "latte": case "cappuccino":
                    makeDrink(choice);
                    break;
                default:
                    System.out.println("\n===========================================================================");
                    System.out.println("This Machine DOES NOT Serve That. Kindly READ the options again. Thank you.");
                    System.out.println("===========================================================================");
            }
        } 
    }

    //printReport method
    private void printReport() {
        //return water, milk, beans, and money
        System.out.println("================== REPORT =================");
        System.out.println("Water: " + resourceManager.getWater() + "ml");
        System.out.println("Milk: " + resourceManager.getMilk() + "ml");
        System.out.println("Beans: " + resourceManager.getCoffeeBeans() + "g");
        System.out.println("Money: $" + String.format("%.2f", money));
        System.out.println("===========================================");
    }

    //makeDrink method
    private void makeDrink(String drinkType) {
        //initialize drink to null
        Coffee coffee = null;
        //ask user for drink
        switch(drinkType){
            case "espresso":
                coffee = new CoffeeEspresso();
                break;
            case "latte":
                coffee = new CoffeeLatte();
                break;
            case "cappuccino":
                coffee = new CoffeeCappuccino();
                break;
            default:
                return;
        }

        //check if enough resources to make the drink
        if (resourceManager.enoughResources(coffee.getWaterCost(), coffee.getMilkCost(), coffee.getBeansCost())){
            //if resources are enough, process the coins, make drink, and deduct resources
            processCoins(coffee);
        }
        else{
            System.out.println("\n===============================================================");
            System.out.println("Sorry there are not enough resources to create your drink. UWU");
            System.out.println("===============================================================");
        }
    }

    //processCoins method
    private void processCoins(Coffee coffee){
        //prompt user for coins
        System.out.println("\nPlease insert coins");
        int quarters = getCoins("Quarters: ");
        int dimes = getCoins("Dimes: ");
        int nickels = getCoins("Nickels: ");
        int pennies = getCoins("Pennies: ");

        double totalMoney = quarters * 0.25 + dimes * 0.10 + nickels * 0.05 + pennies * 0.01;
        System.out.println("Total Payment: " + totalMoney);
    //check if enough money
        if (totalMoney < coffee.getCoffeeCost()){
            System.out.println("\n=======================================================");
            System.out.println("Sorry you might be too broke to purchase the drink. UWU");
            System.out.println("========================================================");
        }
        else{
            //update money
            money += coffee.getCoffeeCost();
            double change = totalMoney - coffee.getCoffeeCost();
            //handle if there is change
            System.out.println("Payment Received! Here is your $" + String.format("%.2f", change) + " change!");
            resourceManager.deductResources(coffee.getWaterCost(),coffee.getMilkCost(), coffee.getBeansCost());
            System.out.println(
                        " \n                                   ██    ██    ██                                      \r\n" + //
                        "                                    ██      ██  ██                                      \r\n" + //
                        "                                    ██    ██    ██                                      \r\n" + //
                        "                                      ██  ██      ██                                    \r\n" + //
                        "                                      ██    ██    ██                                    \r\n" + //
                        "                                                                                        \r\n" + //
                        "                                  ████████████████████                                  \r\n" + //
                        "                                  ██                ██████                              \r\n" + //
                        "                                  ██                ██  ██                              \r\n" + //
                        "                                  ██                ██  ██                              \r\n" + //
                        "                                  ██                ██████                              \r\n" + //
                        "                                    ██            ██                                    \r\n" + //
                        "                                ████████████████████████                                \r\n" + //
                        "                                ██                    ██                                \r\n" + //
                        "                                  ████████████████████                                  \r\n" + //
                        "                                                                                        \r\n" //
                        );
                System.out.println("Here's your coffee! Thank you for purchasing a drink!");
            }
        }

    private int getCoins(String coinType){
        Scanner userInput = new Scanner(System.in);
        int coinCount;
        while(true){
            try {
                System.out.println(coinType);
                // while (!userInput.hasNextInt()){
                //     System.out.println("Sorry that's an invalid number of coins. Try Again.\n"+ coinType);
                //     userInput.next();
                // }
                coinCount = userInput.nextInt();
                if (coinCount >= 0){
                    break;
                }
                //handle negative inputs
                else{
                    System.out.println("Sorry that's an invalid number of coins. Try Again");
                    userInput.next();
                }
            }
            //handle non-integer inputs
            catch (Exception e) {
                System.out.println("Sorry that's an invalid number of coins. Try Again");
                userInput.next();
            }
        }
        return coinCount;
    }
}



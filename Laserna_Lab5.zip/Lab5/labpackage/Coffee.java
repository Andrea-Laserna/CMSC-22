//abstract class that will store coffee creation costs
package labpackage;

public abstract class Coffee {
    protected int waterCost;
    protected int milkCost;
    protected int beansCost;
    protected double coffeeCost;

    public Coffee (int waterCost, int milkCost, int beansCost, double coffeeCost) {
        this.waterCost = waterCost;
        this.milkCost = milkCost;
        this.beansCost = beansCost;
        this.coffeeCost = coffeeCost;
    }

    public abstract String getCoffeeName();

    public int getWaterCost(){
        return waterCost;
    }

    public int getMilkCost(){
        return milkCost;
    }

    public int getBeansCost(){
        return beansCost;
    }

    public double getCoffeeCost(){
        return coffeeCost;
    }
}

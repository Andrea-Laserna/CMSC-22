//concrete class extension of coffee
package labpackage;

public class CoffeeCappuccino extends Coffee {
    public CoffeeCappuccino(){
        super(400,400,150,5.50);
    }

    @Override
    public String getCoffeeName(){
        return "Cappuccino";
    }
}

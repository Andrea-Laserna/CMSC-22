package mypackage;
import java.util.Scanner;

public class CoffeeMachine{
    private ResourceManager resourceManager;
    private double money;

    public CoffeeMachine(ResourceManager resourceManager, double money) {
        this.resourceManager = resourceManager;
        this.money = 0.0;
    }

    public static void main(String[] args) {
        ResourceManager initialResources = new ResourceManager(1000, 1000, 500);
        CoffeeMachine coffeeMachine = new CoffeeMachine(initialResources, 0);
        coffeeMachine.machineOn();
    }

    public void machineOn() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("What would you like? (espresso/latte/cappuccino/off/report):");
            String choice = scanner.nextLine().toLowerCase();

            switch (choice) {
                case "off":
                    System.out.println("Turning off the Coffee Machine. Goodbye!");
                    return;
                case "report":
                    printReport();
                    break;
                case "espresso":
                case "latte":
                case "cappuccino":
                    makeDrink(choice);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    private void printReport() {
        System.out.println("Water: " + resourceManager.getWater() + "ml");
        System.out.println("Milk: " + resourceManager.getMilk() + "ml");
        System.out.println("Beans: " + resourceManager.getBeans() + "g");
        System.out.println("Money: $" + String.format("%.2f", money));
    }

    private void makeDrink(String drinkType) {
        Coffee coffee = null;

        switch (drinkType) {
            case "espresso":
                coffee = new CoffeeEspresso();
                break;
            case "latte":
                coffee = new CoffeeLatte();
                break;
            case "cappuccino":
                coffee = new CoffeeCappuccino();
                break;
            default:
                return;
        }

        if (resourceManager.checkResources(coffee.getWaterCost(), coffee.getMilkCost(), coffee.getBeansCost())){
            processCoins(coffee);
        }
        else {
            System.out.println("Sorry, not enough resources to make that drink.");
        }
    }

    private void processCoins(Coffee coffee) {
        System.out.println("Please insert coins.");
        int quarters = getCoinInput("quarters");
        int dimes = getCoinInput("dimes");
        int nickles = getCoinInput("nickles");
        int pennies = getCoinInput("pennies");
        
        double totalMoney = quarters * 0.25 + dimes * 0.10 + nickles * 0.05 + pennies * 0.01;

        if (totalMoney < coffee.getMoneyCost()) {
            System.out.println("Sorry that's not enough money. Money refunded.");
        }
        else{
            money += coffee.getMoneyCost();
            double change = totalMoney - coffee.getMoneyCost();
            if (change > 0) {
                System.out.println("Here is your $" + String.format("%.2f", change) + " in change.");
            }
            resourceManager.minusResources(coffee.getWaterCost(), coffee.getMilkCost(), coffee.getBeansCost());
            System.out.println("Here is your " + coffee.getCoffeeName() + ". Enjoy!");
        }
    }

    private int getCoinInput(String coinType) {
        Scanner scanner = new Scanner(System.in);
        int coinCount;
        while(true){
            try{
                System.out.println("How many " + coinType + "?:");
                coinCount = scanner.nextInt();
                if (coinCount >= 0) {
                    break;
                }
                else{
                    System.out.println("Sorry, that's not a valid number of coins.");
                    coinCount = scanner.nextInt();
                }
            }
            catch (Exception e) {
                System.out.println("Sorry, that's not a valid number of coins.");
                coinCount = scanner.nextInt();
            }
        }
        return coinCount;
    }
}
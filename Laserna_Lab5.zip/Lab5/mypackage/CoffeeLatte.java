package mypackage;

public class CoffeeLatte extends Coffee {

	public CoffeeLatte() {
		super(100, 100, 50, 2.50);
	}

	@Override
	public String getCoffeeName() {
		return "Latte";

	}

}
